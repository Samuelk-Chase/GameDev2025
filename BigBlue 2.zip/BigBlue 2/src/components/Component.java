package components;

public interface Component {
    // Marker interface: no methods required by default.
    // Used for type-checking and organizing all ECS components.
}

