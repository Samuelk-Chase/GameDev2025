package edu.usu.utils;

public record Tuple4<A, B, C, D>(A item1, B item2, C item3, D item4) {}